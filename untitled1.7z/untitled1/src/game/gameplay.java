package game;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.*;
import javax.swing.*;


/**
 *
 * @author hp
 */
public class gameplay extends JPanel implements KeyListener, ActionListener {
    private boolean play = false , win=false,name=false;
    private String playername=new String("");
    private HighscoreFile highscore=new HighscoreFile();
    private    int score =0;
    public int last_lvl_score=0;
    private Timer timer;
    private  int delay=8;
    private int playerx=310;
    private int bricktype=2;
    private  int ballposx=120;
    private  int ballposy=350;
    private  int ballxdir=-2;
    private  int ballydir=-3;
    private mapgenerator map;
    private int row=3,col=7;
    public int level=1;
    // private Graphics gg;



    public gameplay()
    {
        map =new mapgenerator(row, col,bricktype);
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        timer= new Timer(delay,this);
        timer.start();

    }
    public gameplay(int level)
    {   this.level=level;
        switch (this.level){

        case 2:
            bricktype=3;
            ;
            break;
        case 3:
            bricktype=4;
            break;
        default:
            break;
    }
        map =new mapgenerator(row, col,bricktype);
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        timer= new Timer(delay,this);
        timer.start();

    }
    @Override
    public void paint(Graphics g)
    {

        //background
        g.setColor(Color.BLACK);
        g.fillRect(1, 1, 692, 592);


        //map

        map.draw((Graphics2D)g);


        //borders

        g.setColor(Color.green);
        g.fillRect(0, 0, 3, 592);
        g.fillRect(0, 0, 692, 3);
        g.fillRect(692, 0, 3, 592);


        //the bord
        g.setColor(Color.red);
        g.fillRect(playerx, 550, 100, 8);

        //the ball
        g.setColor(Color.yellow);
        g.fillOval(ballposx, ballposy, 20, 20);
        if (name==false){
            g.setFont(new Font("serf" , Font.BOLD , 25));
            g.drawString("please enter your name:"+playername  , 190 ,300);
        }

        if(map.totalbricks==0)
        {
            play=false;
            ballxdir=0;
            ballydir=0;
            win=true;

            g.setColor(Color.RED);
            g.setFont(new Font("serf" , Font.BOLD , 25));
            g.drawString("Level "+level +" complete your Score :" + score , 190 ,300);


            g.setFont(new Font("serf" , Font.BOLD , 25));
            g.drawString("press Enter to proceed to next level"  , 190 ,350);
            g.setFont(new Font("serf" , Font.BOLD , 25));
            g.drawString("press escape to save highscore"  , 190 ,400);

        }

        if(ballposy>570)
        {
            play=false;
            ballxdir=0;
            ballydir=0;



            g.setColor(Color.RED);
            g.setFont(new Font("serf" , Font.BOLD , 25));
            g.drawString("Game Over , your Score :" +score , 190 ,300);


            g.setFont(new Font("serf" , Font.BOLD , 25));
            g.drawString("press Enter to replay"  , 190 ,350);




        }

        //Score

        g.setColor(Color.WHITE);
        g.setFont(new Font("serf" , Font.BOLD , 25));
        g.drawString("" + score , 590 ,30);

        // g.dispose();

    }


    @Override
    public void actionPerformed(ActionEvent e) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        timer.start();
        if(play)
        {

            if(new Rectangle(ballposx,ballposy,20,20).intersects(new Rectangle(playerx,550,100,8)))
            {
                ballydir=-ballydir;
            }

            A : for (int i = 0; i < map.map.length; i++) {
                for (int j = 0; j < map.map[0].length; j++) {
                    if(map.map[i][j]==1)
                    {
                        int brickx=j*map.brickwidth+88;
                        int bricky=i*map.brickhigh+50;
                        int brickwidth=map.brickwidth;
                        int brickhigh=map.brickhigh;

                        Rectangle rect =new Rectangle(brickx , bricky , brickwidth , brickhigh);
                        Rectangle ballrect=new Rectangle(ballposx, ballposy, 20, 20);
                        Rectangle brickrect=rect;

                        if(ballrect.intersects(brickrect))
                        {
                            map.setBrickvalu(0, i, j);
                            map.totalbricks--;
                            score+=5;

                            if(ballposx + 19 <=brickrect.x || ballposx + 1 >=brickrect.x + brickrect.width)
                            {
                                ballxdir = -ballxdir;
                            }
                            else
                            {
                                ballydir = -ballydir;
                            }
                            break A;
                        }

                    }
                    if(map.map[i][j]==2)
                    {
                        int brickx=j*map.brickwidth+88;
                        int bricky=i*map.brickhigh+50;
                        int brickwidth=map.brickwidth;
                        int brickhigh=map.brickhigh;

                        Rectangle rect =new Rectangle(brickx , bricky , brickwidth , brickhigh);
                        Rectangle ballrect=new Rectangle(ballposx, ballposy, 20, 20);
                        Rectangle brickrect=rect;

                        if(ballrect.intersects(brickrect))
                        {
                            map.setBrickvalu(1, i, j);



                            if(ballposx + 19 <=brickrect.x || ballposx + 1 >=brickrect.x + brickrect.width)
                            {
                                ballxdir = -ballxdir;
                            }
                            else
                            {
                                ballydir = -ballydir;
                            }
                            break A;
                        }

                    }if(map.map[i][j]==3)
                    {
                        int brickx=j*map.brickwidth+88;
                        int bricky=i*map.brickhigh+50;
                        int brickwidth=map.brickwidth;
                        int brickhigh=map.brickhigh;

                        Rectangle rect =new Rectangle(brickx , bricky , brickwidth , brickhigh);
                        Rectangle ballrect=new Rectangle(ballposx, ballposy, 20, 20);
                        Rectangle brickrect=rect;

                        if(ballrect.intersects(brickrect))
                        {
                            map.setBrickvalu(0, i, j);
                            map.totalbricks--;
                            score+=5;

                            //gg.setColor(Color.green);
                            //gg.fillOval(brickx, bricky, 20, 20);


                            if(ballposx + 19 <=brickrect.x || ballposx + 1 >=brickrect.x + brickrect.width)
                            {
                                ballxdir = -ballxdir;
                            }
                            else
                            {
                                ballydir = -ballydir;
                            }
                            break A;
                        }

                    }


                }

            }
            ballposx+=ballxdir;
            ballposy+=ballydir;
            if(ballposx<0)
            {ballxdir=-ballxdir;}
            if(ballposy<0)
            {ballydir=-ballydir;
            }
            if(ballposx>670)
            {ballxdir=-ballxdir;}
        }
        repaint();

    }

    @Override
    public void keyTyped(KeyEvent e) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.



    }

    @Override
    public void keyReleased(KeyEvent e) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    @Override
    public void keyPressed(KeyEvent e) {
        if (name==false){
            if (e.getKeyCode()==KeyEvent.VK_BACK_SPACE) {
                StringBuffer s=new StringBuffer(playername);
                s.deleteCharAt(s.length()-1);
                playername=s.toString();
            }
             if (e.getKeyCode()==KeyEvent.VK_ENTER)
                name=true;
             else {

                 playername = playername + (String.valueOf(e.getKeyChar()));
             }
        }
        if(e.getKeyCode() == KeyEvent.VK_RIGHT && play )
        {
            if(playerx>=600)
            {
                playerx=600;
            }
            else
            {
                moveright();
            }
        }
        if(e.getKeyCode()==KeyEvent.VK_LEFT && play)
        {
            if(playerx<10)
            {
                playerx=10;
            }
            else
            {
                moveleft();

            }
        }
        if(e.getKeyCode()==KeyEvent.VK_ENTER)
        {
            if(!play)
            {
                play = true;
                playerx=310;
                ballposx=120;
                ballposy=350;
                ballxdir=-2;
                ballydir=-3;
                // score=last_lvl_score;
                if (win==true) {
                    level++;
                    last_lvl_score=score;

                    switch (level){

                        case 2:
                            bricktype++;
                            ;
                            break;
                        case 3:
                            bricktype++;
                            break;
                        default:
                            break;
                    }

                    map =new mapgenerator(row, col, bricktype);
                    win=false;
                }
                score=last_lvl_score;
                map.resstmap();
                repaint();
            }
        }
        if(e.getKeyCode()==KeyEvent.VK_ESCAPE)
        {

                highscore.saving_score(score,playername);
            System.out.println(highscore.read_score());

        }

    }

    public void moveright()
    {
        play =true;
        playerx+=20;
    }
    public void moveleft()
    {
        play =true;
        playerx-=20;
    }



}
