package game;


import java.awt.*;

abstract public class Highscore  {
    public abstract void saving_score(int score, String name);

  public abstract String read_score();

}
