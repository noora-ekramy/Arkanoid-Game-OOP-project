package game;

import javax.swing.JFrame;
import javax.swing.*;
import java.io.File;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Toolkit;
import java.awt.Image;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.BorderLayout;
import javax.imageio.ImageIO;
/**
 *
 * @author Moahmed
 */
public class button  implements KeyListener, ActionListener {
    JFrame f = new JFrame("arkanoid");
    private int level=1;
    public button() {

        JButton b = new JButton("PLAY");
        b.setBounds(750, 100, 300, 100);
        b.setForeground(Color.white);
        b.setFont(new Font("Arial", Font.PLAIN, 40));
        b.setBackground(Color.blue);
        f.add(b);
        f.setSize(2000, 1000);
        f.setLayout(null);
        f.setVisible(true);

        JButton c = new JButton("Settings");
        c.setForeground(Color.white);
        c.setFont(new Font("Arial", Font.PLAIN, 40));
        c.setBounds(750, 200, 300, 100);
        c.setBackground(Color.blue);
        f.add(c);
        f.setSize(2000, 1000);
        f.setLayout(null);
        f.setVisible(true);
        JButton t=new JButton("High Score");
        t.setForeground(Color.white);
        t.setFont(new Font("Arial", Font.PLAIN, 40));
        t.setBounds(750, 300, 300, 100);
        t.setBackground(Color.blue);
        f.add(t);
        f.setSize(2000, 1000);
        f.setLayout(null);
        f.setVisible(true);
        JTextField k = new JTextField();

        k.setBounds(750, 400, 300, 100);
        k.setForeground(Color.white);
        k.setFont(new Font("Arial", Font.PLAIN, 40));
        k.setBackground(Color.blue);
        f.add(k);
        k.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {


            }

            @Override
            public void keyPressed(KeyEvent e) {
                try {


                level= Integer.parseInt(String.valueOf(e.getKeyChar()));}
                catch (Exception exp) {
                }
                finally {


                if(e.getKeyCode()==KeyEvent.VK_ENTER)

                {
                gameplay p=new gameplay(level);
                f.dispose();
                f=new JFrame("arkanoid");
                f.setSize(700,600);
                f.setResizable(true);
                f.setVisible(true);
                f.add(p);}}
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });


        JButton d = new JButton("exit");
        d.setBounds(750, 500, 300, 100);
        d.addActionListener(e -> System.exit(0));
        d.setForeground(Color.white);
        d.setFont(new Font("Arial", Font.PLAIN, 40));

        d.setBackground(Color.blue);
        f.add(d);
        f.setSize(2000, 1000);
        f.setLayout(null);
        f.getContentPane().setBackground(Color.cyan);
        f.setVisible(true);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gameplay p=new gameplay();
                f.dispose();
                f=new JFrame("arkanoid");
                f.setSize(700,600);
                f.setResizable(true);
                f.setVisible(true);
                f.add(p);
            }
        });

        t.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                HighscoreWindow display=new HighscoreWindow();
                JFrame r=new JFrame("arkanoid");
                r.setSize(692, 592);
                r.setVisible(true);
                r.getContentPane().setBackground(Color.BLACK);
                r.add(display);

            }

        });

    }



    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}