package game;

import javax.swing.*;
import java.awt.*;

public class HighscoreWindow extends JPanel {
    private HighscoreFile highscoreFile = new HighscoreFile();
    private String scores = new String(highscoreFile.read_score());
    private String[] scorearr;
    private String[] scorearr1;
    private int x = 190, y = 100;

    @Override
    public void paint(Graphics g) {

        scorearr = scores.split("\n");

        g.setColor(Color.BLACK);
        g.fillRect(1, 1, 692, 592);
        g.setColor(Color.RED);
        g.setFont(new Font("serf", Font.BOLD, 25));
        g.drawString("highscores:", 180, 50);
        for (String s1 : scorearr) {
            scorearr1 = s1.split(":");
            for (String s2 : scorearr1) {


                g.setColor(Color.RED);
                g.setFont(new Font("serf", Font.BOLD, 25));
                g.drawString(s2, x, y);
                x += 60;
            }
            x = 190;
            y += 30;
        }
    }
}
