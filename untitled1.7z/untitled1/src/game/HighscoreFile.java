package game;

import java.awt.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;


public class HighscoreFile extends Highscore{
    private FileWriter fileWriter;
    private FileReader fileReader;
    private File f=new File("Highscore.txt");
    private  String scores=new String("");
    public HighscoreFile(){

    }


    public void saving_score(int score, String name) {
        try {
            fileWriter= new FileWriter("Highscore.txt",true);
            fileWriter.write(name+":"+score+"\n");
            fileWriter.close();}
        catch (IOException ioException) {
            ioException.printStackTrace();
        }


    }



    @Override
    public String read_score() {
        try {
            fileReader=new FileReader("Highscore.txt");
            while (fileReader.read()!=-1){

                Scanner scanner=new Scanner(f);
                while (scanner.hasNextLine()){
                scores += "\n" +scanner.nextLine();}
                return scores;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


}

